﻿using UnityEngine;
using UnityEngine.SceneManagement;


public class toStart : MonoBehaviour
{
    public void Forward1()
    {
     SceneManager.LoadScene("Game");
    }
}
