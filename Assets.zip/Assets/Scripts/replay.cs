﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class replay : MonoBehaviour
{

	public GameObject LosttUI;

    public void start()

    {

    SceneManager.LoadScene(SceneManager.GetActiveScene().name);
   

     LosttUI.SetActive(false);

    }


}
