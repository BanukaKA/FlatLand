using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collide1 : MonoBehaviour
{
    public GameObject wonUI;
    public GameObject LostUI;



    void OnCollisionEnter (Collision collisionInfo)
    {

      if(collisionInfo.collider.tag == "Ball1")
      {

         wonUI.SetActive(true);
         LostUI.SetActive(false);

      }

      
    }
    
    
}
