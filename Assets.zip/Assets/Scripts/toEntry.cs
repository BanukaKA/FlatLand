﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class toEntry : MonoBehaviour
{
   public void Forward1()
    {
     SceneManager.LoadScene("Entry");
    }
}
