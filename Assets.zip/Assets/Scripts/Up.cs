using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Up : MonoBehaviour
{
    public Rigidbody rb;
    public Rigidbody rb1;
    public Rigidbody rb2;
    public float upForce = 50f;

    public void Goup()
    {


    rb.AddForce(0, upForce * Time.deltaTime, 0, ForceMode.VelocityChange);
    rb1.AddForce(0, upForce * Time.deltaTime, 0, ForceMode.VelocityChange);
    rb2.AddForce(0, upForce * Time.deltaTime, 0, ForceMode.VelocityChange);

    }


}
