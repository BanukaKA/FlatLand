﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Right : MonoBehaviour
{
    
    public Rigidbody rb;
    public Rigidbody rb1;
    public Rigidbody rb2;
    public float sideForce = 30f;

    public void Goright()
    {


    rb.AddForce(sideForce * Time.deltaTime, 0, 0, ForceMode.VelocityChange);
    rb1.AddForce(sideForce * Time.deltaTime, 0, 0, ForceMode.VelocityChange);
    rb2.AddForce(sideForce * Time.deltaTime, 0, 0, ForceMode.VelocityChange);


    }
}
