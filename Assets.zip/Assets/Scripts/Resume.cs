﻿using UnityEngine;

public class Resume : MonoBehaviour
{
    public GameObject ResumeUI;

    public void ResumeB()

    {



         ResumeUI.SetActive(false);

      


    }
}