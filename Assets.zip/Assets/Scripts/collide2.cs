﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collide2 : MonoBehaviour
{
    public GameObject wonUI;
    public GameObject LostUI;



    void OnCollisionEnter (Collision collisionInfo)
    {

      if(collisionInfo.collider.tag == "Ball")
      {

         wonUI.SetActive(true);
         LostUI.SetActive(false);

     }

      
    }

   
    
    
}
