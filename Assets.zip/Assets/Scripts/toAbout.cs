﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class toAbout : MonoBehaviour
{
    public void About()
    {
     SceneManager.LoadScene("About");
    }
}
