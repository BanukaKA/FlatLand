﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class toHelp : MonoBehaviour
{
    public void goHlp()
    {
     SceneManager.LoadScene("Help");
    }
}
