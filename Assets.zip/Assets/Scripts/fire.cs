﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fire : MonoBehaviour
{
    
    public GameObject FireUI;
    public AudioSource FireAudio;
    public GameObject LostUI;



    void OnCollisionEnter (Collision collisionInfo)
    {

      if(collisionInfo.collider.tag == "Fire")
      {

         FireUI.SetActive(true);
         LostUI.SetActive(false);
         FireAudio.Play();

      }

      
    }
}
