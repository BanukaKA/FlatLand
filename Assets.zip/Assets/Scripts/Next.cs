﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class Next : MonoBehaviour
{
    public void Forward1()
    {
     SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
