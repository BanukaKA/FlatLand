using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class count : MonoBehaviour
{
    float timeRemaining = 70.0f;
    public GameObject LostUI;
    public Text time;


    void Update () {
        timeRemaining -= Time.deltaTime;
        time.text = timeRemaining.ToString("0");
        
    }

    void OnGUI(){
        if(timeRemaining > 0){
            
        }
        else{
            LostUI.SetActive(true);
            timeRemaining = 0;
        }
    }
}
