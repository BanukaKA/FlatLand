﻿using UnityEngine;

public class loadResume : MonoBehaviour
{
    public GameObject ResumeUI;

    void Update()
    {
        

     if(Input.GetKeyDown (KeyCode.Escape))

     {

      ResumeUI.SetActive(true);

     }
       



    }
}
